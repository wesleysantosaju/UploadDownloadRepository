package com.example.uploaddownload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UploaddownloadApplicationTests {

	@Test
	void contextLoads() {
	}

}
